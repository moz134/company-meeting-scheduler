//
//  ScheduleMeetingViewController.swift
//  ios-company-meeting-scheduler
//
//  Created by md mozammil on 12/09/21.
//

import UIKit

open class ScheduleMeetingViewController: UIViewController, UITextFieldDelegate, UITextViewDelegate {
    
    @IBOutlet public var dateTextField: UITextField?
    @IBOutlet public var startTimeTextField: UITextField?
    
    @IBOutlet public var endTimeTextField: UITextField?
    
    @IBOutlet weak var descriptionBox: UITextView!
    
    @IBOutlet public var submitButton: UIButton?
    
    public var currentDate: String = String.empty
    
    var flag: Bool = false
    
    var timePicker = UIDatePicker()
    
    
    
    override open func viewDidLoad() {
        super.viewDidLoad()
        self.startTimeTextField?.delegate = self
        self.endTimeTextField?.delegate = self
        self.descriptionBox?.delegate = self
        self.setUpNavBar()
        self.setUpUI()
        self.timePicker.datePickerMode = .time
    }
    
    func setUpNavBar() {
        
        let previousButton = UIBarButtonItem(title: "Back", style: .plain, target: self, action: #selector(goBack))
        let previousButtonImage = UIBarButtonItem(image: UIImage.init(named: ImageConstants.prevButtonImage), style: .plain, target: self, action: #selector(goBack))
        navigationItem.leftBarButtonItems = [previousButtonImage, previousButton]
        navigationItem.title = "SCHEDULE A MEETING"
    }
    
    func setUpUI() {
        self.dateTextField?.layer.cornerRadius = 5
        self.startTimeTextField?.layer.cornerRadius = 5
        self.endTimeTextField?.layer.cornerRadius = 5
        self.submitButton?.layer.cornerRadius = 5
        self.dateTextField?.text = self.currentDate
        self.dateTextField?.isUserInteractionEnabled = false
        self.startTimeTextField?.inputView = timePicker
        self.endTimeTextField?.inputView = timePicker
        self.descriptionBox.text = "Description"
        self.descriptionBox.textColor = UIColor.lightGray
        let toolbar = UIToolbar()
        toolbar.sizeToFit()
        let doneButton = UIBarButtonItem(title: "Done", style: UIBarButtonItem.Style.bordered, target: self, action: #selector(donedatePicker))
        let spaceButton = UIBarButtonItem(barButtonSystemItem: UIBarButtonItem.SystemItem.flexibleSpace, target: nil, action: nil)
        let cancelButton = UIBarButtonItem(title: "Cancel", style: UIBarButtonItem.Style.bordered, target: self, action: #selector(cancelDatePicker))
        toolbar.setItems([doneButton,spaceButton,cancelButton], animated: false)
        // add toolbar to textField
        startTimeTextField?.inputAccessoryView = toolbar
        endTimeTextField?.inputAccessoryView = toolbar
    }
    @objc
    func donedatePicker(){
        let formatter = DateFormatter()
        formatter.dateFormat = "hh:mm a"
        if flag {
            startTimeTextField?.text = formatter.string(from: timePicker.date)
        } else {
            endTimeTextField?.text = formatter.string(from: timePicker.date)
        }
        self.view.endEditing(true)
    }
    @objc
    func cancelDatePicker(){
        self.view.endEditing(true)
    }
    
    @objc
    func goBack() {
        self.navigationController?.popViewController(animated: false)
    }
    
    public func textFieldDidBeginEditing(_ textField: UITextField) {
        if textField == startTimeTextField || textField == endTimeTextField {
            textField.inputView = timePicker
        }
        if textField == startTimeTextField {
            flag = true
        } else {
            flag = false
        }
    }
    
    public func textViewDidBeginEditing(_ textView: UITextView) {
        if textView.textColor == UIColor.lightGray {
            textView.text = nil
            textView.textColor = UIColor.black
        }
    }
    
    public func textViewDidEndEditing(_ textView: UITextView) {
        if textView.text.isEmpty {
            textView.text = "Description"
            textView.textColor = UIColor.lightGray
        }
    }
}
