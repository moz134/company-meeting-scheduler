//
//  Router.swift
//  ios-company-meeting-scheduler
//
//  Created by md mozammil on 12/09/21.
//

import UIKit
import Foundation

class Router {

    private static var instance: Router?
    private var baseNavigationVC: UINavigationController?

    static let sharedInstance = Router()

    func launchApp() {
        Router.sharedInstance.resetRoot(to: ScheduledMeetingsViewController.instantiate())
    }

    func getNavigationStack() -> UINavigationController {
        guard let navC = self.baseNavigationVC else {
            // swiftlint:disable:next no_fatal_errors
            fatalError(Constants.navigationHierarchyError)
        }
        return navC
    }

    func resetRoot(to new: UIViewController) {

        let rootVC = UINavigationController(rootViewController: new)
        rootVC.navigationBar.isHidden = false

        let appDlgt = UIApplication.shared.delegate

        appDlgt?.window??.rootViewController = rootVC
        appDlgt?.window??.makeKeyAndVisible()

        self.baseNavigationVC = rootVC

    }
}

public extension UIViewController {
    /// Instantiating ViewController as per MicroApp Strategy - MXVM Architecture
    /// - It checks repective XIB first in main bundle, if found thats used for VC otherwise - FMA specific bundle is used - by default
    static func instantiate() -> Self {
        
        if Bundle.main.path(forResource: String(describing: self), ofType: "nib") != nil {
            return Self(nibName: String(describing: self), bundle: .main)
        }

        let sdkBundle = Bundle.resourceBundle(for: self)
        return Self(nibName: String(describing: self), bundle: sdkBundle)
    }
    
    /// Getting Parent Navigation Item instance to setup nav properties currectly
    var navItem: UINavigationItem {
     
     if var parentVC = self.parent {
         while let newParent = parentVC.parent, newParent.navigationController != nil {
             parentVC = newParent
         }
         return parentVC.navigationItem
     }
     
        return self.navigationItem
    }
}


public extension Bundle {

    /// For dynamic / static frameworks - use below mthod to correctly define bundle internally
    static func resourceBundle(for frameworkClass: AnyClass) -> Bundle {
        guard let moduleName = String(reflecting: frameworkClass).components(separatedBy: ".").first else {
            return Bundle.init(for: frameworkClass)
        }

        let frameworkBundle = Bundle(for: frameworkClass)

        guard let resourceBundleURL = frameworkBundle.url(forResource: moduleName, withExtension: "bundle"),
              let resourceBundle = Bundle(url: resourceBundleURL) else {
            return Bundle.init(for: frameworkClass)
        }

        return resourceBundle
    }
}
