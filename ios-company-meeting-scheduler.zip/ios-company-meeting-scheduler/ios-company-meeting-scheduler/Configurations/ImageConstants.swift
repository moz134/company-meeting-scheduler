//
//  ImageConstants.swift
//  ios-company-meeting-scheduler
//
//  Created by md mozammil on 12/09/21.
//

import Foundation

class ImageConstants {
    
    static let nextButtonImage = "nextButton_image"
    static let prevButtonImage = "prevButton_image"
}
