//
//  AppDelegate.swift
//  ios-company-meeting-scheduler
//
//  Created by md mozammil on 12/09/21.
//

import UIKit

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {

    var window: UIWindow?

    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        window = UIWindow(frame: UIScreen.main.bounds)
        Router.sharedInstance.launchApp()
        return true
    }



}

