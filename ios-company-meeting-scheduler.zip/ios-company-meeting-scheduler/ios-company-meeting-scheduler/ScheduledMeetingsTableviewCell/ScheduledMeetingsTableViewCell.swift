//
//  ScheduledMeetingsTableViewCell.swift
//  ios-company-meeting-scheduler
//
//  Created by md mozammil on 12/09/21.
//

import UIKit

class ScheduledMeetingsTableViewCell: UITableViewCell {
    
    @IBOutlet public var meetingTime: UILabel?
    @IBOutlet public var timeMessageSeparator: UIView?
    @IBOutlet public var messageLabel: UILabel?
    @IBOutlet public var cellSeparator: UIView?
    
    var cellData: MeeetingLists?
    
    override func awakeFromNib() {
        super.awakeFromNib()
    }
    
    func setData() {
        let startTim = cellData?.startTime ?? String.empty
        let endtime = cellData?.endTime ?? String.empty
        let hyfen = " - "
        self.meetingTime?.text = startTim + hyfen + endtime
        self.messageLabel?.text = cellData?.message ?? String.empty
    }


}

extension String {
    public static let empty = ""
}
