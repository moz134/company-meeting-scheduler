//
//  ScheduledMeetingsModel.swift
//  ios-company-meeting-scheduler
//
//  Created by md mozammil on 12/09/21.
//

import Foundation


public class ScheduledMeetingsModel {
    public var lists: [MeeetingLists] = []
    
    public init(lists: [MeeetingLists])  {
        self.lists = lists
    }
}

public class MeeetingLists {
    
    var startTime: String = ""
    var endTime: String = ""
    var message: String = ""
    var participants: [String] = []
    
    public init(startTime: String, endTime: String, message: String, participants: [String]) {
        self.startTime = startTime
        self.endTime = endTime
        self.message = message
        self.participants = participants
    }
}
