//
//  ScheduledMeetingsViewController.swift
//  ios-company-meeting-scheduler
//
//  Created by md mozammil on 12/09/21.
//

import UIKit
import Alamofire
import SwiftyJSON

open class ScheduledMeetingsViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    @IBOutlet public var listingTableView: UITableView?
    @IBOutlet public var buttonView: UIView?
    @IBOutlet public var shceduleButton: UIButton?
    
    var indicator = UIActivityIndicatorView()
    var scheduledMettingUIModel: [MeeetingLists] = []
    
    var navBarTitle: String = String.empty
    
    var currentDate: Date?
    
    let refreshControl = UIRefreshControl()
    
    var targetVC: ScheduleMeetingViewController = ScheduleMeetingViewController.instantiate()
    
    override open func viewDidLoad() {
        super.viewDidLoad()
        let date = self.getCurrentDate()
        self.showLoader()
        self.callAPI(date: date)
        self.listingTableView?.delegate = self
        self.listingTableView?.dataSource = self
        self.listingTableView?.register(UINib(nibName: "ScheduledMeetingsTableViewCell", bundle: nil), forCellReuseIdentifier: "ScheduledMeetingsTableViewCell")
        self.listingTableView?.allowsSelection = false
        setUpUI()
        self.setUpNavBar()
        refreshControl.attributedTitle = NSAttributedString(string: "Pull to refresh")
        refreshControl.addTarget(self, action: #selector(self.refresh), for: .valueChanged)
    }
    
    
    @objc
    func refresh()
    {
        self.showLoader()
        self.callAPI(date: self.formatNextPreviousDate(date: self.currentDate ?? Date()))
        self.refreshControl.endRefreshing()
    }
    
    func showLoader() {
        activityIndicator()
        indicator.startAnimating()
        indicator.backgroundColor = .white
    }
    
    func hideLoader() {
        indicator.stopAnimating()
        indicator.hidesWhenStopped = true
    }
    
    func setUpUI() {
        self.shceduleButton?.setTitle("Schedule Company Meeting", for: .normal)
        self.shceduleButton?.layer.cornerRadius = 10
        self.listingTableView?.separatorStyle = .none
    }
    override open func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        self.navigationController?.navigationBar.barTintColor = .white
    }

    override open func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.setUpNavBar()
        self.navigationController?.navigationBar.barTintColor = .white
    }
    
    func setUpNavBar() {
        
        let nextButton = UIBarButtonItem(title: "NEXT", style: .plain, target: self, action: #selector(didTapNextButton(sender:)))
        let nexButtonImage = UIBarButtonItem(image: UIImage.init(named: ImageConstants.nextButtonImage), style: .plain, target: self, action: #selector(didTapNextButton(sender:)))
        let previousButton = UIBarButtonItem(title: "PREV", style: .plain, target: self, action: #selector(didTapPreviousButton(sender:)))
        let previousButtonImage = UIBarButtonItem(image: UIImage.init(named: ImageConstants.prevButtonImage), style: .plain, target: self, action: #selector(didTapNextButton(sender:)))
        navigationItem.rightBarButtonItems = [nexButtonImage, nextButton]
        navigationItem.leftBarButtonItems = [previousButtonImage, previousButton]
        navigationItem.title = self.navBarTitle
        
    }
    
    @IBAction func scheduleMeetingTapped(_ sender: Any) {
            self.navigationController?.pushViewController(targetVC, animated: false)
    }
    
    public func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
    
    public func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return scheduledMettingUIModel.count
    }
    
    public func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "ScheduledMeetingsTableViewCell", for: indexPath) as? ScheduledMeetingsTableViewCell
        cell?.cellData = scheduledMettingUIModel[indexPath.row]
        cell?.setData()
        return cell ?? UITableViewCell()
    }
    
    
    func getCurrentDate() -> String {
        let dateRequireFormat = DateFormatter()
        dateRequireFormat.dateFormat = Constants.outGoingDate
        let dateRequireFormat2 = DateFormatter()
        dateRequireFormat2.dateFormat = Constants.navTitleDateFormatInPortrait
        self.navBarTitle = dateRequireFormat2.string(from: Date())
        self.currentDate = Date()
        return dateRequireFormat.string(from: Date())
    }
    
    
    @objc
    func didTapNextButton(sender: AnyObject){
        self.showLoader()
        let tomorrow = Calendar.current.date(byAdding: .day, value: 1, to: self.currentDate ?? Date())
        self.currentDate = tomorrow
        self.navBarDateFormatter(date: tomorrow ?? Date())
        self.callAPI(date: self.formatNextPreviousDate(date: tomorrow ?? Date()))
    }
    
    @objc
    func didTapPreviousButton(sender: AnyObject){
        self.showLoader()
        let yesterday = Calendar.current.date(byAdding: .day, value: -1, to: self.currentDate ?? Date())
        self.currentDate = yesterday
        self.navBarDateFormatter(date: yesterday ?? Date())
        self.callAPI(date: self.formatNextPreviousDate(date: yesterday ?? Date()))
    }
    
    
    func navBarDateFormatter(date: Date) {
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy-MM-dd HH:mm:ss"
        let myString = formatter.string(from: date )
        let yourDate = formatter.date(from: myString)
        formatter.dateFormat = Constants.navTitleDateFormatInPortrait
        self.navBarTitle = formatter.string(from: yourDate ?? Date())
        targetVC.currentDate = self.navBarTitle
    }
    
    func formatNextPreviousDate(date: Date) -> String {
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy-MM-dd HH:mm:ss"
        let myString = formatter.string(from: date )
        let yourDate = formatter.date(from: myString)
        formatter.dateFormat = Constants.outGoingDate
        return formatter.string(from: yourDate ?? Date())
    }
    
    func callAPI(date: String) {
        let url = Constants.url
        let parameters = ["date": date]
        AF.request(url, method: .get, parameters: parameters, encoding: URLEncoding.default).responseDecodable(of: [Response].self) { response in
            self.hideLoader()
            print(response)
            switch response.result {
            case .success(_):
                self.parseJSON(data: response.data!)
                self.updateUI()
            case .failure(_):
                print(response.error)
            }
            
            }
    }
    
    
    
    func updateUI() {
        self.setUpNavBar()
        let bool = self.checkPastDate(date1: self.formatNextPreviousDate(date: self.currentDate ?? Date()), date2: self.formatNextPreviousDate(date: Date()))
        if bool {
            self.shceduleButton?.isUserInteractionEnabled = false
        } else {
            self.shceduleButton?.isUserInteractionEnabled = true
        }
        self.listingTableView?.reloadData()
    }
    
    func activityIndicator() {
        indicator = UIActivityIndicatorView(frame: CGRect(x: 0, y: 0, width: 40, height: 40))
        indicator.style = UIActivityIndicatorView.Style.gray
        indicator.center = self.view.center
        self.view.addSubview(indicator)
    }
    
    func parseJSON(data: Data) {
        let decoder = JSONDecoder()
        do {
            
            let decoderData = try decoder.decode([Response].self, from: data)
            var unsSortedLists: [MeeetingLists] = []
            var formatedDateLists: [MeeetingLists] = []
            print(decoderData)
            for value in decoderData {
                let meetinData = MeeetingLists(startTime: value.start_time, endTime: value.end_time, message: value.description, participants: value.participants)
                unsSortedLists.append(meetinData)
            }
            self.scheduledMettingUIModel = unsSortedLists.sorted(by: { self.sortDAted(date1: $0.startTime, date2: $1.startTime) })
            
            for value in scheduledMettingUIModel {
                let meetingData = MeeetingLists(startTime: self.formatDate(formatDateString: value.startTime), endTime: self.formatDate(formatDateString: value.endTime), message: value.message, participants: value.participants)
                formatedDateLists.append(meetingData)
            }
            self.scheduledMettingUIModel = []
            self.scheduledMettingUIModel = formatedDateLists
            print(scheduledMettingUIModel)
        } catch {
            DispatchQueue.main.async {
                print(error)
                return
            }
            
        }
        
    }
    
    func checkPastDate(date1: String, date2: String) -> Bool {
        let f = DateFormatter()
        f.dateFormat = "dd/MM/yyyy"
        return f.date(from: date1) ?? Date() < f.date(from: date2) ?? Date()
    }

    
    func formatDate(formatDateString: String) -> String {
        let inFormatter = DateFormatter()
        inFormatter.dateFormat = "HH:mm"
        let outFormatter = DateFormatter()
        outFormatter.dateFormat = "hh:mm a"
        let datess = inFormatter.date(from: formatDateString) ?? Date()
        return outFormatter.string(from: datess)
    }
    
    func sortDAted(date1: String, date2: String) -> Bool {
        let f = DateFormatter()
        f.dateFormat = "HH:mm"
        return f.date(from: date1) ?? Date() < f.date(from: date2) ?? Date()
    }

    
}


struct Response: Decodable {
    
    let start_time: String
    let end_time: String
    let description: String
    let participants: [String]

    enum CodingKeys: String, CodingKey {
        case start_time, end_time
        case description, participants
    }
}


