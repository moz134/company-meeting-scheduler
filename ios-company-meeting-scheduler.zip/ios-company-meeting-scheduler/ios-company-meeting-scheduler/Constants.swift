//
//  Constants.swift
//  ios-company-meeting-scheduler
//
//  Created by md mozammil on 12/09/21.
//



import Foundation

class Constants {
    
    static let navigationHierarchyError = "Navigation Hierarchy Not set"
    static let url = "https://fathomless-shelf-5846.herokuapp.com/api/schedule"
    static let outGoingDate = "dd/MM/yyyy"
    static let outGoingLandScapeDate = "dd/MM/yyyy"
    static let navTitleDateFormatInPortrait = "dd-MM-yyyy"
}
